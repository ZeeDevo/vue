<script setup></script>

<template>
  <div class="p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5">
      <h1 class="display-5 fw-bold">VUE 3 (VITE) + LARAVEL 10</h1>
      <p class="col-md-8 fs-4">
        Belajar CRUD dengan Vue 3 dan Laravel 10 di SantriKoding.com
      </p>
    </div>
  </div>
</template>
