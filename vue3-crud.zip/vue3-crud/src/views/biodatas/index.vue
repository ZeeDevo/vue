<script setup>

    //import ref and onMounted
    import { ref, onMounted } from 'vue';

    //import api
    import api from '../../api';

    //define state
    const biodatas = ref([]);

    //method fetchDatabiodatas
    const fetchDatabiodatas = async () => {

        //fetch data 
        await api.get('/api/biodatas')

            .then(response => {

                //set response data to state "biodatas"
                biodatas.value = response.data.data.data

            });
    }

    //run hook "onMounted"
    onMounted(() => {

        //call method "fetchDatabiodatas"
        fetchDatabiodatas();
    });

    //method deletebiodata
    const deleteBiodata = async (id) => {

        //delete biodata with API
        await api.delete(`/api/biodatas/${id}`)
            .then(() => {

                //call method "fetchDatabiodatas"
                fetchDatabiodatas();
            })

    };

</script>

<template>
    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <router-link :to="{ name: 'biodatas.create' }"
                    class="btn btn-md btn-success rounded shadow border-0 mb-3">ADD NEW biodata</router-link>
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th scope="col">foto</th>
                                    <th scope="col">Nama</th>
                                    <th scope="col">Tempat Lahir</th>
                                    <th scope="col">Tanggal Lahir</th>
                                    <th scope="col">Jenis Kelamin</th>
                                    <th scope="col">Alamat</th>
                                    <th scope="col">Telepon</th>
                                    <th scope="col" style="width:15%">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-if="biodatas.length == 0">
                                    <td colspan="8" class="text-center">
                                        <div class="alert alert-danger mb-0">
                                            Data Belum Tersedia!
                                        </div>
                                    </td>
                                </tr>
                                <tr v-else v-for="(biodata, index) in biodatas" :key="index">
                                    <td class="text-center">
                                        <img :src="biodata.foto" width="200" class="rounded-3" />
                                    </td>
                                    <td>{{ biodata.nama }}</td>
                                    <td>{{ biodata.tempatlahir }}</td>
                                    <td>{{ biodata.tanggallahir }}</td>
                                    <td>{{ biodata.jeniskelamin }}</td>
                                    <td>{{ biodata.alamat }}</td>
                                    <td>{{ biodata.telepon }}</td>
                                    <td class="text-center">
                                        <router-link :to="{ name: 'biodatas.edit', params:{id: biodata.id} }"
                                            class="btn btn-sm btn-primary rounded-sm shadow border-0 me-2">EDIT</router-link>
                                        <button @click.prevent="deleteBiodata(biodata.id)"
                                            class="btn btn-sm btn-danger rounded-sm shadow border-0">DELETE</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>