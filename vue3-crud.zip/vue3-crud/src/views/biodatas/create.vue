<script setup>
    //import ref
    import { ref } from "vue";

    //import router
    import { useRouter } from 'vue-router';

    //import api
    import api from "../../api";

    //init router
    const router = useRouter();

    //define state
    const nama = ref("");
    const tempatlahir = ref("");
    const tanggallahir = ref("");
    const jeniskelamin = ref("");
    const alamat = ref("");
    const telepon = ref("");
    const foto = ref("");
    const errors = ref([]);

    //method for handle file changes
    const handleFileChange = (e) => {
        //assign file to state
        foto.value = e.target.files[0];
    };

    //method "storePost"
    const storePost = async () => {

        //init formData
        let formData = new FormData();

        //assign state value to formData
        formData.append("nama", nama.value);
        formData.append("tempatlahir", tempatlahir.value);
        formData.append("tanggallahir", tanggallahir.value);
        formData.append("jeniskelamin", jeniskelamin.value);
        formData.append("alamat", alamat.value);
        formData.append("telepon", telepon.value);
        formData.append("foto", foto.value);

        //store data with API
        await api.post('/api/biodatas', formData)
            .then(() => {
                //redirect
                router.push({ path: "/biodatas" });
            })
            .catch((error) => {
                //assign response error data to state "errors"
                errors.value = error.response.data;
            });
    };
</script>

<template>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <form @submit.prevent="storePost()">
                            <div class="mb-3">
                                <label class="form-label fw-bold">foto</label>
                                <input type="file" class="form-control" @change="handleFileChange($event)">
                                <div v-if="errors.foto" class="alert alert-danger mt-2">
                                    <span>{{ errors.foto[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Nama</label>
                                <input type="text" class="form-control" v-model="nama" placeholder="Nama">
                                <div v-if="errors.nama" class="alert alert-danger mt-2">
                                    <span>{{ errors.nama[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Tempatlahir</label>
                                <input type="text" class="form-control" v-model="tempatlahir" placeholder="tempat lahir">
                                <div v-if="errors.tempatlahir" class="alert alert-danger mt-2">
                                    <span>{{ errors.tempatlahir[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Tanggallahir</label>
                                <input type="date" class="form-control" v-model="tanggallahir" placeholder="tanggallahir">
                                <div v-if="errors.tanggallahir" class="alert alert-danger mt-2">
                                    <span>{{ errors.tanggallahir[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Jeniskelamin</label>
                                <input type="text" class="form-control" v-model="jeniskelamin" placeholder="jeniskelamin">
                                <div v-if="errors.jeniskelamin" class="alert alert-danger mt-2">
                                    <span>{{ errors.jeniskelamin[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Alamat</label>
                                <input type="text" class="form-control" v-model="alamat" placeholder="alamat">
                                <div v-if="errors.alamat" class="alert alert-danger mt-2">
                                    <span>{{ errors.alamat[0] }}</span>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Telepon</label>
                                <input type="int" class="form-control" v-model="telepon" placeholder="telepon">
                                <div v-if="errors.telepon" class="alert alert-danger mt-2">
                                    <span>{{ errors.telepon[0] }}</span>
                                </div>
                            </div>
                            <button type="submit"
                                class="btn btn-md btn-primary rounded-sm shadow border-0">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>